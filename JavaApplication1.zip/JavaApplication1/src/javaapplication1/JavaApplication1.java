/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication1;
import java.util.Scanner;
/**
 *
 * @author Computer
 */
public class JavaApplication1 {
    
    public static void setskilldata3(String sk1,String sk2,String sk3){
        String skill_1 = sk1;
        String skill_2 = sk2;
        String skill_3 = sk3;
        System.out.println("-*-*-*-*-*-*Skill 3 *-*-*-*-*-");
        System.out.println("Skill 1 :"+skill_1);
        System.out.println("Skill 2 :"+skill_2);
        System.out.println("Skill 3 :"+skill_3);
        
    }    
    public void setskilldata2(String sk1,String sk2,String sk3){
        String skill_1 = sk1;
        String skill_2 = sk2;
        String skill_3 = sk3;
        System.out.println("-*-*-*-*-*-*Skill 2 *-*-*-*-*-");
        System.out.println("Skill 1 :"+skill_1);
        System.out.println("Skill 2 :"+skill_2);
        System.out.println("Skill 3 :"+skill_3);
        
    }    
    
    
    
    public static void main(String[] args) {
        JavaApplication1 Ja = new JavaApplication1();
        Scanner sc = new Scanner(System.in);
        Method st = new Method();
        //////////////////////////////////////////////
        
        /////////////////////////////////////////////
        //st.SumRang(3, 8);
        //System.out.println(st.SumRang(3,8));
        System.out.print("Start :");
        int Start = sc.nextInt();
        System.out.print("End :");
        int End = sc.nextInt();
        System.out.println("==========================================");
        System.out.println(st.SumRang(Start, End));
        System.out.println("==========================================");
        
        //st.skill_1 = "python";
        //st.skill_2 = "java";
        //st.skill_1 = "Node.JS";
        st.setskilldata("Python_1", "java_1", "Node.Js_1");
        Ja.setskilldata2("Python_2", "java_2", "Node.Js_2");
        JavaApplication1.setskilldata3("Python_3", "java_3", "Node.Js_3");
        
    }
}
