/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication1;


/**
 *
 * @author Computer
 */
public class Method {
   private String skill_1,skill_2,skill_3;
    
    public int SumRang(int start,int end){
        int sum =0;
        for(int i =start; i<= end; i++){
        sum = sum +i;
        }
    return sum;
}
    public void setskilldata(String sk1,String sk2,String sk3){
        skill_1 = sk1;
        skill_2 = sk2;
        skill_3 = sk3;
        System.out.println("-*-*-*-*-*-*FROM Method Skill  *-*-*-*-*-");
        System.out.println("Skill 1 :"+skill_1);
        System.out.println("Skill 2 :"+skill_2);
        System.out.println("Skill 3 :"+skill_3);
        
        
        
    }
}
